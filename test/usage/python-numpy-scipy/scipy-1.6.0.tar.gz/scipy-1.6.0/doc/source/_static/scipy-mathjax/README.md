# scipy-mathjax

Scipy-variant of stripped-down Mathjax.

Only keep TeX-AMS input with SVG + stix-web output.

Run rebuild.sh to rebuild the files.

Note that this requires node.js npm being available.

Based on https://github.com/mathjax/MathJax-grunt-cleaner.git

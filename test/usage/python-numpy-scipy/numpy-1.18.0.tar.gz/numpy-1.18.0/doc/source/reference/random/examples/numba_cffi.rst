Extending via Numba and CFFI
----------------------------

.. literalinclude:: ../../../../../numpy/random/_examples/numba/extending_distributions.py
    :language: python
